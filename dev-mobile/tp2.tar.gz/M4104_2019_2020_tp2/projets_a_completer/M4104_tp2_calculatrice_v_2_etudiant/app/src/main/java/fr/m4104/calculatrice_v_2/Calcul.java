package fr.m4104.calculatrice_v_2;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by B. LEMAIRE on 2019.
 */

    public class Calcul extends Activity {


    // Affichage du résultat du calcul
    private TextView tv_calcul;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // A compléter

        /**
         * Désérialisation des ressources
         */

        // A compléter

        /**
         * Mise en place de l'écouteur du bouton calculer
         */

        // A compléter


        /**
         * Récupération de l'Intent qui a servi à lancer
         * cette activité
         */
        // A Compléter

        /**
         * Récupération des extras
         */

        // A compléter


        /**
         * Calcul du résultat, affichage du résultat
         * et renvoi du résultat à l'activité principale
         */

        // A compléter

    }

    /**
     * Mise en place des écouteurs
     * Permet de mettre en place les fonctions de call-back
     * lié aux évènements
     */
    private void initConnection() {
        /** Dans l'écouteur il faut :
         *
         * - Instancier un Intent explicite
         * - Charger les extras dans l'Itent pour le calcul
         * - Lancer l'activité de calcul
         */

        // A compléter
    }
}
