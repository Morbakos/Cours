public class TestNavire {
	public static void main(String[] args) {
		Navire m1 = new Navire();
		Navire m11 = new Navire(5, 4);

		System.out.println(m1.toString());
		System.out.println(m11.toString());
		//System.out.println(m12.toString());
	}
}