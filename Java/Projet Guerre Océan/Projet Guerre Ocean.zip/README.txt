Ce qui a été fait:
- La classe Munition et ses héritières (Missile, Torpille et Mine)
- La classe Navire

Ce qui n'a pas été fait:
- Les héritières de la classe Navire
- La classe Grille
- La classe Partie

Le lancement d'une partie n'est pas fonctionnelle.